package gui;

public enum TypeOrdination {PN, FAST, SKAEV}

package ordination;

import java.time.LocalTime;

public class DagligSkaev {
    // TODO


    public void opretDosis(LocalTime tid, double antal) {
        // TODO
    }
}

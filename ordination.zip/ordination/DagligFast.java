package ordination;

public class DagligFast {
    // TODO
}
